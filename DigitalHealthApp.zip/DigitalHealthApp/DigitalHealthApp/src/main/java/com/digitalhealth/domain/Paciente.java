package com.digitalhealth.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table
public class Paciente {

	@Id
	@GeneratedValue
	@Column(name = "idPaciente")
	private Long id;
	
	
	//Paciente
	@Column
	@JsonProperty
	private String nomePaciente;
	
	@Column
	@JsonProperty
	private String cpfPaciente;
	
	@Column
	@JsonProperty
	private String senhaPaciente;
	
	@Column
	@JsonProperty
	private String dataNascimento;
	
	@Column
	@JsonProperty
	private String endereco;
	
	@Column
	@JsonProperty
	private String telefonePaciente;
	
	@Column
	@JsonProperty
	private String idadePaciente;
	
	@Column
	@JsonProperty
	private String sexoPaciente;
	
	//construtor vazio 
	public Paciente() {
		
		
	}

	//construtor preenchido
	public Paciente(Long id, String nomePaciente, String cpfPaciente, String senhaPaciente, String dataNascimento,
			String endereco, String telefonePaciente, String idadePaciente, String sexoPaciente) {
		this.id = id;
		this.nomePaciente = nomePaciente;
		this.cpfPaciente = cpfPaciente;
		this.senhaPaciente = senhaPaciente;
		this.dataNascimento = dataNascimento;
		this.endereco = endereco;
		this.telefonePaciente = telefonePaciente;
		this.idadePaciente = idadePaciente;
		this.sexoPaciente = sexoPaciente;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomePaciente() {
		return nomePaciente;
	}

	public void setNomePaciente(String nomePaciente) {
		this.nomePaciente = nomePaciente;
	}

	public String getCpfPaciente() {
		return cpfPaciente;
	}

//	public void setCpfPaciente(String cpfPaciente) {
//		this.cpfPaciente = cpfPaciente;
//	}

	public String getSenhaPaciente() {
		return senhaPaciente;
	}

//	public void setSenhaPaciente(String senhaPaciente) {
//		this.senhaPaciente = senhaPaciente;
//	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getTelefonePaciente() {
		return telefonePaciente;
	}

	public void setTelefonePaciente(String telefonePaciente) {
		this.telefonePaciente = telefonePaciente;
	}

	public String getIdadePaciente() {
		return idadePaciente;
	}

	public void setIdadePaciente(String idadePaciente) {
		this.idadePaciente = idadePaciente;
	}

	public String getSexoPaciente() {
		return sexoPaciente;
	}

	public void setSexoPaciente(String sexoPaciente) {
		this.sexoPaciente = sexoPaciente;
	}
	
	
	
	
	
	
	
}
