package com.digitalhealth.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table
public class Farmaceutico {
	
	@Id
	@GeneratedValue
	@Column(name = "idFarmacia")
	private Long id;
	
	@Column
	@JsonProperty
	private String nomeFarmacia;
	
	@Column
	@JsonProperty
	private String nomeFarmaceutico;
	
	@Column
	@JsonProperty
	private String crmFarmaceutico;
	
	@Column
	@JsonProperty
	private String senha;
	
	
	//construtor vazio
	public Farmaceutico() {
			
	}
	

	public Farmaceutico(String nomeFarmacia, String nomeFarmaceutico, String crmFarmaceutico, String senha) {
		super();
		this.nomeFarmacia = nomeFarmacia;
		this.nomeFarmaceutico = nomeFarmaceutico;
		this.crmFarmaceutico = crmFarmaceutico;
		this.senha = senha;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeFarmacia() {
		return nomeFarmacia;
	}


	public void setNomeFarmacia(String nomeFarmacia) {
		this.nomeFarmacia = nomeFarmacia;
	}


	public String getNomeFarmaceutico() {
		return nomeFarmaceutico;
	}


	public void setNomeFarmaceutico(String nomeFarmaceutico) {
		this.nomeFarmaceutico = nomeFarmaceutico;
	}


	public String getCrmFarmaceutico() {
		return crmFarmaceutico;
	}


//	public void setCrmFarmaceutico(String crmFarmaceutico) {
//		this.crmFarmaceutico = crmFarmaceutico;
//	}


	public String getSenha() {
		return senha;
	}


//	public void setSenha(String senha) {
//		this.senha = senha;
//	}
	
	
	
	

	
	
}
