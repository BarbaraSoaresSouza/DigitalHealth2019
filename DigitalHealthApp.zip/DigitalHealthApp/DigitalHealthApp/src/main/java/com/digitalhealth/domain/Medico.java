package com.digitalhealth.domain;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.digitalhealth.credenciais.CredenciaisMedicos;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table
public class Medico {

	//medico
	
	@Id
	@GeneratedValue
	@Column(name = "idMedico")
	private Long id;
	
	
	@Column
	@JsonProperty
	private String nomeMedico;
	
	@JsonProperty
	@Embedded
	private CredenciaisMedicos credenciais;
	
	@Column
	@JsonProperty
	private String telefone;
	
	@Column
	@JsonProperty
	private String email;
	
	
	
	

	//constutor vazio
	public Medico() {
		
	}

	//constutor cheio


	public Medico(String nomeMedico, String telefone, String email, CredenciaisMedicos credenciais ) {
		super();
		this.nomeMedico = nomeMedico;
		this.telefone = telefone;
		this.email = email;
		this.credenciais = credenciais;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeMedico() {
		return nomeMedico;
	}

	public void setNomeMedico(String nomeMedico) {
		this.nomeMedico = nomeMedico;
	}

	


	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public CredenciaisMedicos getCredenciais() {
		return credenciais;
	}
	
	public void setCredenciais(CredenciaisMedicos credenciais) {
		this.credenciais = credenciais;
	}


	
	
	
}
