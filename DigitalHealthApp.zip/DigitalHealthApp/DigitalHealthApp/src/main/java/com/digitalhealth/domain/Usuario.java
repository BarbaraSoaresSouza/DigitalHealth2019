package com.digitalhealth.domain;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.digitalhealth.credenciais.CredenciaisMedicos;
import com.fasterxml.jackson.annotation.JsonProperty;



@Entity
@Table // sem passar o nome, continua usuário;
public class Usuario {
	
	@Id
	@GeneratedValue
	@Column(name = "idUsuario")
	private Long id;
	
	

	@Column(name = "nomeUsuario")
	private String nome;
	
	@Column(name= "tipo")
	private String tipo;
	
	//construtor vazio para o banco fazer o acesso.
	public Usuario() {
		
	}
	
	
//	public Usuario(String nome, Integer idade) {
//		this.setNome(nome);
//		this.setIdade(idade);
//	}

	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getNome() {
		return nome;
	}

	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}
	


	public String getTipo() {
		return tipo;
	}


	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	
	


//	public String getLogin() {
//		return login;
//	}
//
//
//	public void setLogin(String login) {
//		this.login = login;
//	}
//
//
//	public String getSenha() {
//		return senha;
//	}
//
//
//	public void setSenha(String senha) {
//		this.senha = senha;
//	}
//	
	
	
	
}
