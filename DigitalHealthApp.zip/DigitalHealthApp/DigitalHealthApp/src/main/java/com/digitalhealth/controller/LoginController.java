package com.digitalhealth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;



import com.digitalhealth.domain.Usuario;
import com.digitalhealth.repository.TodosUsuarios;
import com.digitalhealth.controller.Token;
import com.digitalhealth.credenciais.CredenciaisMedicos;


@RestController
public class LoginController {

	private TodosUsuarios todosUsuarios;

	
	
	@Autowired
	public LoginController(TodosUsuarios todosUsuarios) {
		super();
		this.todosUsuarios = todosUsuarios;
		
	}



	@PostMapping("/login")
	public ResponseEntity<Double> validarLogin(@RequestBody CredenciaisMedicos credenciais) {
			Usuario usuarios = null;
			
				if(usuarios != null) {
					double token  = Token.generateToken();
							Token.addToken(token);
					return ResponseEntity.ok(token);
			
		}
		else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(401d); 
		}	
	}
	

	

	@PostMapping("/logout")
	public ResponseEntity<String> logout(@RequestHeader("token") double token)  { 
		Token.getTokenList().remove((Double) token); 
		
		return ResponseEntity.ok("Deslogado com sucesso"); 
	}
	
	
	@PostMapping("/Cadastro")
	public ResponseEntity<Usuario> cadastro(@RequestBody Usuario usuario){
	
		Usuario usuarioCadastrado = todosUsuarios.save(usuario);

		return ResponseEntity.ok(usuarioCadastrado);	
	}
	

}
