package com.digitalhealth.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import com.digitalhealth.credenciais.CredenciaisMedicos;
import com.digitalhealth.domain.Medico;
import com.digitalhealth.domain.Usuario;
import com.digitalhealth.repository.TodosMedicos;


@RestController
public class MedicoController {

	private TodosMedicos todosMedicos;
	
	
	@Autowired
	public MedicoController(TodosMedicos todosMedicos) {
		
		this.todosMedicos = todosMedicos;
	}
	
	
	@PostMapping("/cadastroMedico")
	public ResponseEntity<Medico> cadastro(@RequestBody Medico medicos){
	
		Medico medicoCadastrado = todosMedicos.save(medicos);

		return ResponseEntity.ok(medicoCadastrado);	
	}
	
	
//	@PostMapping("/logoutMedicod")
//	public ResponseEntity<String> logout(@RequestHeader("token") double token)  { 
//		Token.getTokenList().remove((Double) token); 
//		
//		return ResponseEntity.ok("Deslogado com sucesso"); 
//	}
	
	@PostMapping("/loginMedico")
	public ResponseEntity<Double> validarLogin(@RequestBody CredenciaisMedicos credenciais) {
			Medico medicos = this.todosMedicos.buscarUsuario(credenciais);
			
				if(medicos != null) {
					double token  = Token.generateToken();
							Token.addToken(token);
					return ResponseEntity.ok(token);
			
		}
		else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(401d); 
		}	
	}
	
	@PutMapping("/AtualizarMedico/{id}")
	public ResponseEntity<Medico> atualizarMedico(@RequestBody Medico medicos, @PathVariable("id") Long id){
			
		Optional<Medico> oldMedico = this.todosMedicos.findById(id);
		
		if(oldMedico.isPresent()) {
			
			if(medicos.getNomeMedico() == null) {
				medicos.setNomeMedico(oldMedico.get().getNomeMedico());
			}
			
			//fazer if para outras informações basicas ATRIBUTOS
			
			medicos.setCredenciais(oldMedico.get().getCredenciais());
			medicos.setId(id);
			
			Medico novoMedico = this.todosMedicos.save(medicos);
			
			return ResponseEntity.ok(novoMedico);
		}
		
		return ResponseEntity.badRequest().body(null);
		
	}
	
	
	
	
	
}
